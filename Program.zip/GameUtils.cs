﻿using System;

namespace mini_RPG;

public static class GameUtils
{
    public static Random random = new Random();

    public static Enemy RandomEnemy()
    {
        if (random.Next(0, 11) < 5)
            return new Goblin();
        else if (random.Next(0, 11) == 10)
            return new Dragon();
        else
            return new Orc();
    }
}
