﻿using System;

namespace mini_RPG;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        int choice = 0;
        Console.WriteLine("Вітаємо у міні RPG грі!");
        do
        {
            Console.WriteLine("Оберіть дію:");
            Console.WriteLine("1. Створити героя");
            Console.WriteLine("2. Почати бій з випадковим ворогом");
            Console.WriteLine("3. Вийти з гри");
            choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Введіть ім'я героя:");
                    string name = Console.ReadLine();
                    Hero hero = new Hero(name, 100, 10, 5);
                    Console.WriteLine($"Герой {name} створений!");
                    break;
                case 2:
                    // Here you would implement the logic to start a fight with a random enemy
                    Console.WriteLine("Починаємо бій з випадковим ворогом...");
                    break;
                case 3:
                    Console.WriteLine("Вихід з гри. До побачення!");
                    break;
                default:
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
        } while (choice != 3);
    }
}