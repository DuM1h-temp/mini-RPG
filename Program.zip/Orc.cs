﻿using System;

namespace mini_RPG;

public class Orc : Enemy
{
    private string name = "Орк";
    private int health = 50;
    private int attackPower = 18;
    private EnemyType type = EnemyType.Orc;
    override public void AttackHero(Hero hero)
    {
        hero.TakeDamage(attackPower);
    }
    override public void TakeDamage(int damage)
    {
        health -= damage;
        Console.WriteLine($"{name} отримав {damage} шкоди! Здоров'я залишилось: {health}");
    }
}
