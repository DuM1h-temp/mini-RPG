﻿using System;

namespace mini_RPG;

enum EnemyType
{
    Goblin,
    Orc,
    Dragon
}
