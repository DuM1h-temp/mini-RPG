﻿using System;

namespace mini_RPG;

public class Goblin : Enemy
{
    private string name = "Гоблін";
    private int health = 30;
    private int attackPower = 8;
    private EnemyType type = EnemyType.Goblin;

    override public void AttackHero(Hero hero)
    {
        hero.TakeDamage(attackPower);
    }
    override public void TakeDamage(int damage)
    {
        health -= damage;
        Console.WriteLine($"{name} отримав {damage} шкоди! Здоров'я залишилось: {health}");
    }
}
