﻿using System;

namespace mini_RPG;

public struct Item
{
    private string itemName;
    private int Power;
}
