﻿using System;

namespace mini_RPG;

public class Dragon : Enemy
{
    private string name = "Дракон";
    private int health = 100;
    private int attackPower = 25;
    private EnemyType type = EnemyType.Dragon;

    override public void AttackHero(Hero hero)
    {
        hero.TakeDamage(attackPower);
    }

    override public void TakeDamage(int damage)
    {
        health -= damage;
        Console.WriteLine($"{name} отримав {damage} шкоди! Здоров'я залишилось: {health}");
    }
}
