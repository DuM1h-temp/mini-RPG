﻿using System;

namespace mini_RPG
{
    abstract public class Enemy
    {
        private string name;
        private int health = 0;
        private int attackPower;
        private EnemyType type;

        public string GetName() { return name; }
        abstract public void AttackHero(Hero hero);
        abstract public void TakeDamage(int damage);
    }
}